#include <stdio.h>
int main(int argc, const char* argv[]) {
  char array[] = "abcde";
  printf("%s", array);
  printf("\n");
  return 0;
}