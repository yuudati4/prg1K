#include <stdio.h>
#define HELLO "Hello, World!"

int main(int argc, const char* argv[]){

    printf("%s\n",HELLO);

    return 0;
}