#include <stdio.h>
void printFunc(void){
  printf("1\n");
  printf("2\n");  
  printf("3\n");
  printf("4\n");
  printf("5\n");
}

int main(int argc, const char* argv[]) {
    printFunc();
    return 0;
}